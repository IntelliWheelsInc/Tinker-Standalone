# Abacus-mvp

Getting Started:

Check out the project (follow Github instructions)
in the project directory:
(1) npm install
(2) bower install
